public void forceAttractionPoint(Object node1, Object node2) {
    double dx = graph.getCellGeometry(node1).getX() - graph.getCellGeometry(node2).getX();
    double dy = graph.getCellGeometry(node1).getY() - graph.getCellGeometry(node2).getY();
    
    double currentDistance = Math.sqrt(dx * dx + dy * dy);
    double k = 0.9;
    double force = (-k * currentDistance);
    double forceX =  force * (dx / currentDistance) ;
    double forceY =  force * (dy / currentDistance) ;
    
    mxGeometry geometry = graph.getCellGeometry(node2);
    geometry.setX(geometry.getX() - forceX);
    geometry.setY(geometry.getY() - forceY);
    graph.getModel().setGeometry(node2, geometry);
    }
}