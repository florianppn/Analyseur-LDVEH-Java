procedure findPath(points)
    start <- points[0]
    end <- points[dernier element de points]
    queue <- file vide
    distance <- dictionnaire vide
    Ajouter start a initialPath
    Ajouter initialPath a queue
    distance[Id(start)] <- 0
    tant que queue n'est pas vide faire
        currentPath <- retirer le premier element de queue
        currentPoint <- dernier element de currentPath
        si currentPoint = end alors
            retourner currentPath
        fin si
        pour chaque enfant dans currentPoint.obtenirPointsEnfants() faire
            nouvelleDistance <- distance[Identifiant(currentPoint)] + 1
            si Identifiant(enfant) n'est pas dans distance ou nouvelleDistance < distance[Identifiant(enfant)] alors
                newPath <- copie de current path
                ajoute enfant a newPath
                Ajouter newPath a queue
                distance[Identifiant(enfant)] <- nouvelleDistance
            fin si
        fin pour
    fin tant que 
    retourner liste vide
fin procedure