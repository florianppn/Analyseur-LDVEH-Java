public void forceExpulsionPoint(Object node1, Object node2) {
    mxGeometry geometry1 = graph.getCellGeometry(node1);
    mxGeometry geometry2 = graph.getCellGeometry(node2);

    double dx = geometry2.getX() - geometry1.getX();
    double dy = geometry2.getY() - geometry1.getY();
    double currentDistance = Math.sqrt(dx * dx + dy * dy);

    if (currentDistance > 0) {
        double k = 70;
        double forceMagnitude = k / (currentDistance * currentDistance);
        double forceX = forceMagnitude * (dx / currentDistance);
        double forceY = forceMagnitude * (dy / currentDistance);
        geometry2.setX(geometry2.getX() + forceX);
        geometry2.setY(geometry2.getY() + forceY);
    }
}

